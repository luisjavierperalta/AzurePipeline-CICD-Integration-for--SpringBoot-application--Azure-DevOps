package com.practice.welcome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelcomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
